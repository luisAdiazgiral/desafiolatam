i = list(range(0,50))
for x in i:
    print(f'Iteración {x+1}')