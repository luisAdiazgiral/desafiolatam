cuenta_regresiva = int(input("Ingrese un número para comenzar la cuenta:  "))
while cuenta_regresiva > 0:
    tmp = cuenta_regresiva
    print("Iteración {}".format(tmp))
    cuenta_regresiva -=1