frase=''
for x in range(5):
    frase = frase + str(x+1)
    print(frase)