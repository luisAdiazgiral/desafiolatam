base = '*****'
lateral = '*   *'
for x in range(5):
    if (x == 0) or (x == 4):
        print(base)
    else:
        print(lateral)